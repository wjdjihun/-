가변 가중치 모델 · 서울 경동시장 식자재 6품목
서비스는 2026년 6월까지 확보한 유효 사례 276건으로 학습한 단일 모델을 사용합니다.
service-forecasts.json의 서비스 예측은 선택월별 당시 입력을 전체 학습 모델에 적용한 값입니다.
선택월 실측이 학습에 포함될 수 있으므로 성능 평가는 rolling-monthly-comparison.csv를 사용합니다.
월별 검증 모델은 선택월 직전 말일까지의 자료로 학습하며 2026년 6월 검증은 270건을 사용합니다.
comparison-* 파일은 2024년 12월에 학습을 고정한 초기 비교 실험입니다.
재현: python scripts/evaluate-kamis-adaptive.py --export-site --output <dir>
