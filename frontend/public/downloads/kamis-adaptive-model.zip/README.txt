가변 가중치 모델 · 서울 경동시장 식자재 6품목
웹앱은 과거 선택월 직전 말일까지 확보한 모든 유효 사례로 다시 학습한 결과를 사용합니다.
2026년 6월 예측은 2026년 5월까지의 270개 사례로 학습했으며, 6월 실측은 6월 오차 계산에 사용했습니다.
2026년 7월 이후 예측은 2026년 6월까지의 276개 사례로 학습한 adaptive-model-full.json을 사용합니다.
rolling-monthly-comparison.csv와 rolling-evaluation-summary.json은 웹앱과 같은 예측의 검증 결과입니다.
comparison-* 파일은 2024년 12월에 학습을 고정했던 초기 비교 실험입니다.
재현: python scripts/evaluate-kamis-adaptive.py --export-site --output <dir>
