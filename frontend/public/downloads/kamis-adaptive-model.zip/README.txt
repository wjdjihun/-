가변 가중치 모델 · 서울 경동시장 식자재 6품목
2025.01~2026.06 검증은 2024.12까지 학습한 adaptive-model.json을 사용.
2026.07 이후는 2026.06까지의 전체 유효 사례로 재학습한 adaptive-model-full.json을 사용.
재현: python scripts/evaluate-kamis-adaptive.py --export-site --output <dir>
