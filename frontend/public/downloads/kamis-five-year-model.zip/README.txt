물가레이더 · 2021-07-01 ~ 2026-06-30 소매가격 학습
시장: 서울 경동시장 / 소매 / 상품 등급
품목: 봄배추 1포기, 양파 1kg, 수미(노지) 감자 100g
2025년 9월 자료는 공백으로 두었으며 감자의 동일 규격 관측은 2023-05-25부터 확보했습니다.

추가로 받은 2021년·2024년 자료에서 조건에 맞는 453건은 공식 과거 자료와 일치해 한 번만 반영했습니다.
20221231 파일은 2021년 파일과 동일했고, 20231231 파일의 실제 관측연도는 2003년이었습니다.

prices.csv는 관측가격, 공개 시점을 고려해 결합한 환율과 식품지수를 담고 있습니다.
model_a_refit.ubj는 독립 평가를 마친 뒤 전체 기간의 유효 학습 사례 1,688건으로 재학습한 XGBoost 파일입니다.
일부 과거 가격 변수를 관측할 수 없을 때 XGBoost의 결측치 처리를 사용합니다.
metrics.json의 오차는 시간순 홀드아웃에 대한 결과이며 전체 기간 재학습 모델의 새 점수가 아닙니다.
재현: backend/에서 python -m ml.train --data <prices.csv> --output <output-dir> --model-a-only --refit --allow-sparse-prices

출처
한국농수산식품유통공사 KAMIS: https://data.mafra.go.kr/opendata/data/indexOpenDataDetail.do?data_id=20251017000000002761
최근 KAMIS 가격 파일: https://www.data.go.kr/data/15072357/fileData.do
FRED DEXKOUS: https://fred.stlouisfed.org/series/DEXKOUS
World Bank Commodity Price Data: https://www.worldbank.org/en/research/commodity-markets
