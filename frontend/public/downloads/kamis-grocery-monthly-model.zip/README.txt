PriceRadar AI · 6품목 월평균 가격 예측
학습 자료: 2021-07-01~2026-06-30 서울 경동시장 상품 등급 소매 관측.
품목: 양파 1kg, 대파 1kg, 애호박 1개, 다다기오이 10개, 국산 깐마늘 1kg, 팽이버섯 150g.
model.ubj는 2026-07 예측에 사용한 최신 월평균 XGBoost입니다.
monthly-forecasts.json의 과거 월 결과는 각각 해당 월 이전 자료만으로 다시 학습한 평가용 예측입니다.
2026-06 실측은 해당 월 검증에만 활용했습니다.
재현: 프로젝트에서 python scripts/generate-kamis-monthly.py --prices <prices.csv> --model <model.ubj>
가격: https://www.data.go.kr/data/15072357/fileData.do
과거 가격: https://data.mafra.go.kr/opendata/data/indexOpenDataDetail.do?data_id=20251017000000002761
환율: https://fred.stlouisfed.org/series/DEXKOUS
식품지수: https://www.worldbank.org/en/research/commodity-markets
